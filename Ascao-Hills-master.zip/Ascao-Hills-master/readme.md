## Trabajo de Ascao Hills

* Hasta el momento tenemos todo hecho, ahora toca juntar todo que de eso se encargara Adrian. 

* Por otro lado tenemos que ir empezando a crear responsive. 

* Los puntos de corte los teneis al final del documento css, diferenciar que etiquetas son de vuestra seccion indicandolo con un titulo global.

